package com.busBoys;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Bus_Boys {
    private JPanel panel1;

    private JPanel panHome;
    private JPanel panRequests;
    private JPanel panLogin;
    private JPanel panSupervisor;
    private JPanel panContact;
    private JPanel panAdmin;

    private JLabel lblHome;
    private JLabel lblRequests;
    private JLabel lblLogin;
    private JLabel lblSupervisor;
    private JLabel lblContact;
    private JLabel lblAdmin;

    private JButton butReqHome;
    private JButton butLogHome;
    private JButton butSupHome;
    private JButton butConHome;
    private JButton butAdmHome;
    private JButton butHomeLogin;
    private JButton butHomeRoutes;
    private JButton butHomeRequests;
    private JButton butHomeContact;
    private JTextArea texHomeDescription;
    private JLabel lblUsername;
    private JLabel lblPassword;
    private JTextField fldUsername;
    private JPasswordField fldPassword;
    private JButton butLoginEmployee;
    private JButton butLoginAdmin;
    private JButton butLoginSupervisor;
    private JLabel lblSubmit;
    private JTextField txtStationNumberSupervised;
    private JTextField txtStationNameSupervised;
    private JTextField txtNumberOfEmployeesSupervised;
    private JLabel lblStationNumberSupervised;
    private JLabel lblStationNameSupervised;
    private JLabel lblNumberOfEmployeesSupervised;
    private JButton butSupViewBuses;
    private JLabel lblSupViewEmployees;
    private JButton butSupViewDrivers;
    private JButton butSupViewMechanics;
    private JButton butSupViewCashiers;
    private JButton butSupViewJanitors;
    private JComboBox comboBoxTaxis;
    private JButton butReqSubmit;
    private JLabel lblAvailableTaxis;
    private JLabel lblContactInfo;
    private JLabel lblConPhone;
    private JLabel lblConEmail;
    private JLabel lblConComplaint;
    private JTextArea txtAreaComplaintText;
    private JButton butConSubmitComplaint;
    private JButton butAdminDeleteVehicle;
    private JButton butAdminAddEmployee;
    private JButton butAdminDeleteEmployee;
    private JButton butAdminAddVehicle;
    private JLabel lblAdminVehicle;
    private JLabel lblAdminEmployee;
    String id;

    public static boolean isNumeric(String str)
    {
        try
        {
            double d = Double.parseDouble(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }

    public Bus_Boys() {
        //Initially set all panels invisible except home.
        panHome.setVisible(true);
        panRequests.setVisible(false);
        panAdmin.setVisible(false);
        panContact.setVisible(false);
        panLogin.setVisible(false);
        panSupervisor.setVisible(false);

        //So description text will wrap.

        texHomeDescription.append("Welcome to Bus Boys!\nWe are your go-to destination to get to your destination.\n" +
                "Press the request button to request a vehicle.\nPress the routes button to view bus routes.\n" +
                "Press the contact button to view our contact information.\n");
        texHomeDescription.setLineWrap(true);

        //Label Font Size
        String titleFont = "Times New Roman";
        lblHome.setFont(new Font(titleFont, Font.PLAIN, 30));
        lblAdmin.setFont(new Font(titleFont, Font.PLAIN, 30));
        lblRequests.setFont(new Font(titleFont, Font.PLAIN, 30));
        lblContact.setFont(new Font(titleFont, Font.PLAIN, 30));
        lblSupervisor.setFont(new Font(titleFont, Font.PLAIN, 30));
        lblLogin.setFont(new Font(titleFont, Font.PLAIN, 30));

        //-----Home Panel Listeners-------------------------------------------------------------
        butHomeLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panHome.setVisible(false);
                panLogin.setVisible(true);
            }
        });
        butHomeRoutes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query route info
                int k = 0;
                int i = 1;
                String router[] = new String[50];
                String Current_stop[] = new String[50];
                String Next_stop[] = new String[50];
                String Bus_num[] = new String[50];
                String all[] = new String[100];


                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement routes = conn.createStatement();
                    ResultSet rs = routes.executeQuery("select Current_Stop, Next_Stop, Bus_Num from PUBLIC_BUS");
                    while(rs.next()){
                        all[k] = "Bus #" + i + " INFO: ";
                        i++;
                        k++;
                        all[k] = "Current Stop: " + rs.getString("Current_Stop");
                        k++;
                        all[k] = "Next Stop: " + rs.getString("Next_Stop");
                        k++;
                        all[k] = "Bus Number: " + rs.getString("Bus_Num");
                        k++;
                        all[k] = "                   ";
                        k++;
                    }
                    JOptionPane.showMessageDialog(null, all);
                }

                catch(SQLException p) {
                p.printStackTrace();
                 }


            }
        });
        butHomeRequests.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panHome.setVisible(false);
                panRequests.setVisible(true);
            }
        });
        butHomeContact.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panHome.setVisible(false);
                panContact.setVisible(true);
            }
        });

        //-----Request Panel Listeners----------------------------------------------------------
        butReqHome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panRequests.setVisible(false);
                panHome.setVisible(true);
            }
        });

        //TODO query available taxi list
        //TODO create loop to add taxi list to comboBoxTaxis like below.
        try {
            int a = 0;
            int b = 0;
            int c = 1;
            String all[] = new String [100];
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
            Statement taxis = conn.createStatement();
            ResultSet rs = taxis.executeQuery("select Make, vModel, vYear, numSeats from VEHICLE, TAXI where VEHICLE.Vehicle_ID = TAXI.Taxi_ID");
            while (rs.next()) {
                all[a] = rs.getString("Make");
                a++;
                all[a] = rs.getString("vModel");
                a++;
                all[a] = rs.getString("vYear");
                a++;
                all[a] = rs.getString("numSeats");
                a++;
            }

           while( b < a){
               comboBoxTaxis.addItem("Taxi " + c + ": " + all[b] + " " + all[b+1] + ", " + all[b+2] + ", Num Seats = " + all[b+3]);
                b = b+4;
                c++;



           }
                comboBoxTaxis.setSelectedIndex(0);
                //TODO add action listener to combo box list
        }

        catch(SQLException p) {
            p.printStackTrace();
        }
        butReqSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO add submit functionality?
                JOptionPane.showMessageDialog(null, "Request Submitted.");
                panRequests.setVisible(false);
                panHome.setVisible(true);
            }
        });


        //-----Login Panel Listeners-------------------------------------------------------------
        butLogHome.addActionListener(new ActionListener() { //Home Button
            @Override
            public void actionPerformed(ActionEvent e) {
                panLogin.setVisible(false);
                panHome.setVisible(true);
            }
        });
        butLoginEmployee.addActionListener(new ActionListener() { //Employee Login Button
            @Override
            public void actionPerformed(ActionEvent e) {
                int ch = 0;
                try {
                    int a = 0;
                    int b = 0;
                    int c = 1;
                    int d;
                    int check = 0;
                    String all[] = new String[100];
                    String userEnter = fldUsername.getText();
                    char arrUserPass[] = fldPassword.getPassword();
                    String userPass = "";
                    for (d = 0; d < arrUserPass.length; d++) {
                        userPass += arrUserPass[d];
                    }

                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement login = conn.createStatement();
                    ResultSet rs = login.executeQuery("select USER_ID, USERNAME, PASSWORD from USERS");
                    while (rs.next()) {
                        if(rs.getString("username").equals(userEnter) && rs.getString("password").equals(userPass)) {
                            id = rs.getString("user_id");
                            ch = 1;
                        }
                        //id = rs.getString("USER_ID");
                        //all[a] = rs.getString("USERNAME");
                        //a++;
                        //all[a] = rs.getString("PASSWORD");
                    }


                } catch (SQLException p) {
                    p.printStackTrace();
                }


                if (ch == 1) {
                    try {
                        String all[] = new String[100];
                        int a = 0;
                        int b = 0;
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "select Fname, Lname, Employee_ID, Wage, Address, Station_ID from EMPLOYEE where Employee_ID =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1,id);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            all[a] = rs.getString("Fname");
                            a++;
                            all[a] = rs.getString("Lname");
                            a++;
                            all[a] = "Employee ID: " + rs.getString("Employee_ID");
                            a++;
                            all[a] = "Wage: " + rs.getString("Wage");
                            a++;
                            all[a] = "Address: " +rs.getString("Address");
                            a++;
                            all[a] = "Station Number: " + rs.getString("Station_ID");
                            a++;
                        }
                        JOptionPane.showMessageDialog(null, all);

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Wrong username or Password");

                }
            }});
        butLoginSupervisor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int ch = 0;
                try {
                    //to populate supervisor panel info
                    int a = 0;
                    int b = 0;
                    int c = 1;
                    int d;
                    int check = 0;
                    String all[] = new String[100];
                    String userEnter = fldUsername.getText();
                    char arrUserPass[] = fldPassword.getPassword();
                    String userPass = "";
                    for (d = 0; d < arrUserPass.length; d++) {
                        userPass += arrUserPass[d];
                    }

                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement login = conn.createStatement();
                    ResultSet rs = login.executeQuery("select USER_ID, USERNAME, PASSWORD from USERS");
                    while (rs.next()) {
                        if(rs.getString("username").equals(userEnter) && rs.getString("password").equals(userPass)) {
                            id = rs.getString("user_id");
                            //ch = 1;
                        }
                    }


                }

                catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    ch = 0;
                    System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select super_num from SUPERVISER");
                    while (rs.next()) {
                        if(rs.getString("super_num").equals(id))
                        {
                            ch = 1;
                        }
                    }
                }
                 catch (SQLException p) {
                    p.printStackTrace();
                }

                String stationNumber = null, stationName = null, numberOfEmployees = null;

                try {

                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select station_id, No_supervised, Station_name from SUPERVISER, STATION where SUPERVISER.station_id = STATION.Station_no && SUPERVISER.super_num =?";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                       stationNumber = rs.getString("station_id");
                       stationName = rs.getString("Station_name");
                       numberOfEmployees = rs.getString("No_supervised");
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }


                if (ch == 1) {
                    panLogin.setVisible(false);
                    panSupervisor.setVisible(true);
                    txtStationNumberSupervised.setText(stationNumber);
                    txtStationNameSupervised.setText(stationName);
                    txtNumberOfEmployeesSupervised.setText(numberOfEmployees);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Wrong username or Password");

                }


            }
        });
        butLoginAdmin.addActionListener(new ActionListener() { //admin login button
            @Override
            public void actionPerformed(ActionEvent e) {
                int d;

                String userEnter = fldUsername.getText();
                char arrUserPass[] = fldPassword.getPassword();
                String userPass = "";
                for(d = 0; d < arrUserPass.length; d++) {
                    userPass += arrUserPass[d];
                }

                if((userEnter.equals("admin")) && userPass.equals("admin")) {
                    panLogin.setVisible(false);
                    panAdmin.setVisible(true);
                }

                else
                    JOptionPane.showMessageDialog(null, "Wrong username or Password");

            }
        });

        //-----Supervisor Panel Listeners----------------------------------------------------------

        butSupHome.addActionListener(new ActionListener() { //home button
            @Override
            public void actionPerformed(ActionEvent e) {
                panSupervisor.setVisible(false);
                panHome.setVisible(true);
                id = "";
            }
        });
        butSupViewBuses.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query buses supervised
                String all[] = new String[100];
                int a = 0;
                int b = 0;
                try {
                    //System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select bus_num, V_ID, Station_Num, Vehicle_ID, Make, vModel from SUPERVISER, PUBLIC_BUS, VEHICLE where SUPERVISER.station_id = PUBLIC_BUS.Station_num && PUBLIC_BUS.V_ID = VEHICLE.Vehicle_ID && SUPERVISER.super_num = ?";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    //Statement l = conn.createStatement();
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        all[a] = "Bus Number: " + rs.getString("bus_num");
                        a++;
                        all[a] = "Vehicle ID: " + rs.getString("V_ID");
                        a++;
                        all[a] = "Station Number: " + rs.getString("Station_num");
                        a++;
                        all[a] = "Make: " + rs.getString("Make");
                        a++;
                        all[a] = "Model: " + rs.getString("vModel");
                        a++;
                        all[a] = "              ";
                        a++;
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, all);
            }
        });
        butSupViewDrivers.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query drivers supervised
                String all[] = new String[100];
                int a = 0;
                int b = 0;
                try {
                    //System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select Fname, Lname, bus_num, emp_id from EMPLOYEE, DRIVER where EMPLOYEE.Sup_ID =? && EMPLOYEE.Employee_ID = DRIVER.emp_id";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    //Statement l = conn.createStatement();
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        all[a] = "First Name: " + rs.getString("Fname");
                        a++;
                        all[a] = "Last Name: " + rs.getString("Lname");
                        a++;
                        all[a] = "Bus ID: " + rs.getString("bus_num");
                        a++;
                        all[a] = "Employee ID: " + rs.getString("emp_id");
                        a++;
                        all[a] = "              ";
                        a++;
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, all);

            }
        });
        butSupViewMechanics.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query mechanics supervised

                String all[] = new String[100];
                int a = 0;
                int b = 0;
                try {
                    //System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select Fname, Lname, work_on, mech_num from EMPLOYEE, MECHANIC where EMPLOYEE.Sup_ID =? && EMPLOYEE.Employee_ID = MECHANIC.mech_num";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    //Statement l = conn.createStatement();
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        all[a] = "First Name: " + rs.getString("Fname");
                        a++;
                        all[a] = "Last Name: " + rs.getString("Lname");
                        a++;
                        all[a] = "Works on: " + rs.getString("work_on");
                        a++;
                        all[a] = "Employee ID: " + rs.getString("mech_num");
                        a++;
                        all[a] = "              ";
                        a++;
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, all);
            }
        });
        butSupViewCashiers.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query cashiers supervised
                String all[] = new String[100];
                int a = 0;
                int b = 0;
                try {
                    //System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select Fname, Lname, Register_pass, cash_id from EMPLOYEE, CASHIER where EMPLOYEE.Sup_ID =? && EMPLOYEE.Employee_ID = CASHIER.cash_id";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    //Statement l = conn.createStatement();
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        all[a] = "First Name: " + rs.getString("Fname");
                        a++;
                        all[a] = "Last Name: " + rs.getString("Lname");
                        a++;
                        all[a] = "Register Password: " + rs.getString("Register_pass");
                        a++;
                        all[a] = "Employee ID: " + rs.getString("cash_id");
                        a++;
                        all[a] = "              ";
                        a++;
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, all);
            }
        });
        butSupViewJanitors.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO query janitors supervised
                String all[] = new String[100];
                int a = 0;
                int b = 0;
                try {
                    //System.out.println(id);
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "select Fname, Lname, Station_num, jan_id from EMPLOYEE, JANITOR where EMPLOYEE.Sup_ID =? && EMPLOYEE.Employee_ID = JANITOR.jan_id";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1,id);
                    //Statement l = conn.createStatement();
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        all[a] = "First Name: " + rs.getString("Fname");
                        a++;
                        all[a] = "Last Name: " + rs.getString("Lname");
                        a++;
                        all[a] = "Station Number: " + rs.getString("Station_num");
                        a++;
                        all[a] = "Employee ID: " + rs.getString("jan_id");
                        a++;
                        all[a] = "              ";
                        a++;
                    }
                }
                catch (SQLException p) {
                    p.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, all);
            }
        });

        //-----Contact Panel Listeners--------------------------------------------------------------
        butConHome.addActionListener(new ActionListener() { //home button
            @Override
            public void actionPerformed(ActionEvent e) {
                panContact.setVisible(false);
                panHome.setVisible(true);
            }
        });
        butConSubmitComplaint.addActionListener(new ActionListener() { //complaint button
            @Override
            public void actionPerformed(ActionEvent e) {
                //TODO submit complaint functionality, update query?
                JOptionPane.showMessageDialog(null,"Complaint Submitted");
                panContact.setVisible(false);
                panHome.setVisible(true);
            }
        });

        //-----Admin Panel Listeners---------------------------------------------------------------
        butAdmHome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panAdmin.setVisible(false);
                panHome.setVisible(true);
            }
        });
        butAdminAddVehicle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean showError = false;
                String inMake = null, inModel = null, inVIN = null, inStryear = null;
                int inYear = 0;
                do {
                    if (showError) JOptionPane.showMessageDialog(null, "Please enter all vehicle info.");
                    showError = true;
                    inMake = null; inModel = null; inVIN = null; inStryear = null;
                    inYear = 0;
                    inMake = JOptionPane.showInputDialog("Enter Vehicle Make:");
                    inModel = JOptionPane.showInputDialog("Enter Vehicle Model:");
                    inStryear = JOptionPane.showInputDialog("Enter Year:");
                    if (isNumeric(inStryear) && inStryear != null) {
                        inYear = Integer.parseInt(inStryear);
                    }
                    inVIN = JOptionPane.showInputDialog("Enter VIN:");
                    if (inMake != null && inModel !=null && inYear != 0 && inVIN != null)
                    {
                        showError = false; //to control whether loop should continue
                    }
                } while (showError);
                //TODO query add vehicle
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "INSERT into VEHICLE (Make, vModel, vYear, Vehicle_ID)" + " VALUES (?, ?, ?, ?)";
                    ps = conn.prepareStatement(strQuery);
                    ps.setString(1, inMake);
                    ps.setString(2, inModel);
                    ps.setString(3, inStryear);
                    ps.setString(4, inVIN);
                    ps.execute();

                }
                //ResultSet rs = ps.executeQuery();

                catch (SQLException p) {
                    p.printStackTrace();
                }

                JOptionPane.showMessageDialog(null, "Vehicle Added");
            }
        });
        butAdminDeleteVehicle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String VIN = JOptionPane.showInputDialog("Enter the VIN of Vehicle to delete:");
                //TODO query VIN, return error if does not exist
                //TODO delete query
                int check = 0;

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select Vehicle_ID from VEHICLE");
                    while (rs.next()) {
                        if (rs.getString("Vehicle_ID").equals(VIN)) {
                            check = 8;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select Taxi_ID from TAXI");
                    while (rs.next()) {
                        if (rs.getString("Taxi_ID").equals(VIN)) {
                            check = 1;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select V_ID from PUBLIC_BUS");
                    while (rs.next()) {
                        if (rs.getString("V_ID").equals(VIN)) {
                            check = 2;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select Bus_ID from PRIVATE_BUS");
                    while (rs.next()) {
                        if (rs.getString("Bus_ID").equals(VIN)) {
                            check = 3;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                if (check == 1) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from TAXI where Taxi_ID =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, VIN);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Vehicle Deleted.");
                }

                else if (check == 2) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from PUBLIC_BUS where Bus_Num =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, VIN);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Vehicle Deleted.");
                }

                else if (check == 3) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from PRIVATE_BUS where Bus_ID =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, VIN);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Vehicle Deleted.");
                }


                else{
                    if (check ==  8) {
                        try {
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                            PreparedStatement ps = null;
                            String strQuery = "DELETE from VEHICLE where VEHICLE.Vehicle_ID =?";
                            ps = conn.prepareStatement(strQuery);
                            ps.setString(1, VIN);
                            ps.execute();
                            JOptionPane.showMessageDialog(null, "Vehicle Deleted.");
                        }
                        catch (SQLException p) {
                            p.printStackTrace();
                        }
                    }

                    else{
                        JOptionPane.showMessageDialog(null, "Delete Halted");
                    }

                }

            }
        });
        butAdminAddEmployee.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean showError = false;
                String inStrYearsWorked = null, inEmployeeID = null, inFname = null, inLname = null, inStrWage = null;
                String inAddress = null, inSupervisorID = null, inStationID = null;
                int inYearsWorked = 0;
                double inWage = 0;
                do {
                    inStrYearsWorked = null; inEmployeeID = null; inFname = null; inLname = null; inStrWage = null;
                    inAddress = null; inSupervisorID = null; inStationID = null;
                    inYearsWorked = 0; inWage = 0;
                    if (showError) JOptionPane.showMessageDialog(null, "Please enter all employee info.");
                    showError = true;
                    inStrYearsWorked = JOptionPane.showInputDialog("Enter the number of years worked:");
                    if (isNumeric(inStrYearsWorked) && inStrYearsWorked != null)
                    {
                        inYearsWorked = Integer.parseInt(inStrYearsWorked);
                    }
                    inEmployeeID = JOptionPane.showInputDialog("Enter the employee's ID");
                    inFname = JOptionPane.showInputDialog("Enter the employee's first name:");
                    inLname = JOptionPane.showInputDialog("Enter the employee's lame name:");
                    inStrWage = JOptionPane.showInputDialog("Enter the employee's wage");
                    if (isNumeric(inStrWage) && inStrWage != null)
                    {
                        inWage = Double.parseDouble(inStrWage);
                    }
                    inAddress = JOptionPane.showInputDialog("Enter the employee's address:");
                    inSupervisorID = JOptionPane.showInputDialog("Enter the ID of the employee's supervisor:");
                    inStationID = JOptionPane.showInputDialog("Enter the ID of the station the employee works at:");
                    if (inStrYearsWorked != null && inEmployeeID != null && inFname != null && inLname != null && inWage != 0
                            && inAddress != null && inSupervisorID != null && inStationID != null)
                    {
                        showError = false; //To control whether loop should continue
                    }
                } while (showError);
                //TODO query add employee

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    PreparedStatement ps = null;
                    String strQuery = "INSERT into EMPLOYEE (Years_worked, Employee_ID, Fname, Lname, Wage, Address, Sup_ID, Station_ID )" + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    ps = conn.prepareStatement(strQuery);
                    ps.setInt(1, inYearsWorked);
                    ps.setString(2, inEmployeeID);
                    ps.setString(3, inFname);
                    ps.setString(4, inLname);
                    ps.setDouble(5, inWage);
                    ps.setString(6, inAddress);
                    ps.setString(7, inSupervisorID);
                    ps.setString(8, inStationID);
                    ps.execute();


                    JOptionPane.showMessageDialog(null, "Employee Added.");
                }

                catch (SQLException p) {
                    p.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error in Input.");
                }

            }
        });
        butAdminDeleteEmployee.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String employeeID = JOptionPane.showInputDialog("Enter the ID of the Employee to delete:");
                //TODO check whether employee ID exists in database
                //TODO delete employee query
                String all[] = new String[100];
                int a = 0;
                int b = 0;
                int check = 0;

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select Employee_ID from EMPLOYEE");
                    while (rs.next()) {
                        if (rs.getString("Employee_ID").equals(employeeID)) {
                            check = 8;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }
                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select emp_id from DRIVER");
                    while (rs.next()) {
                        if (rs.getString("emp_id").equals(employeeID)) {
                            check = 1;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select mech_num from MECHANIC");
                    while (rs.next()) {
                        if (rs.getString("mech_num").equals(employeeID)) {
                            check = 2;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select jan_id from JANITOR");
                    while (rs.next()) {
                        if (rs.getString("jan_id").equals(employeeID)) {
                            check = 3;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select cash_id from CASHIER");
                    while (rs.next()) {
                        if (rs.getString("cash_id").equals(employeeID)) {
                            check = 4;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select hr_id from HR");
                    while (rs.next()) {
                        if (rs.getString("hr_id").equals(employeeID)) {
                            check = 5;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }

                try {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                    Statement l = conn.createStatement();
                    ResultSet rs = l.executeQuery("select super_num from SUPERVISER");
                    while (rs.next()) {
                        if (rs.getString("super_num").equals(employeeID)) {
                            check = 6;
                        }
                    }
                } catch (SQLException p) {
                    p.printStackTrace();
                }


                if (check == 1) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from DRIVER where emp_id =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }

                else if (check == 2) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from MECHANIC where mech_num =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }

                else if (check == 3) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from JANITOR where jan_id =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }

                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }

                else if (check == 4) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from CASHIER where cash_id =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }


                else if (check == 5) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from HR where hr_id =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }


                else if (check ==  6) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                        PreparedStatement ps = null;
                        String strQuery = "DELETE from SUPERVISER where sup_num =?";
                        ps = conn.prepareStatement(strQuery);
                        ps.setString(1, employeeID);
                        ps.execute();

                    } catch (SQLException p) {
                        p.printStackTrace();
                    }


                    JOptionPane.showMessageDialog(null, "Employee Deleted.");
                }

                else{
                    if (check ==  8) {
                        try {
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
                            PreparedStatement ps = null;
                            String strQuery = "DELETE from EMPLOYEE where EMPLOYEE.Employee_ID =?";
                            ps = conn.prepareStatement(strQuery);
                            ps.setString(1, employeeID);
                            ps.execute();
                            JOptionPane.showMessageDialog(null, "Employee Deleted.");
                        }
                        catch (SQLException p) {
                            p.printStackTrace();
                        }
                    }

                    else{
                        JOptionPane.showMessageDialog(null, "Delete Halted");
                        }

                }

            }
        });
    }


    private static void initializeConnection() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbase", "root", "toor");
            if (conn != null) {
                System.out.println("Connected to database");
            }
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.toString(), "Error: No connection to database",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }


    }

    public static void main(String[] args) {
        initializeConnection();
        JFrame frame = new JFrame("Bus_Boys");
        frame.setContentPane(new Bus_Boys().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
