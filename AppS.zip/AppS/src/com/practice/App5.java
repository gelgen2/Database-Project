package com.practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App5 {
    public JPanel panel_Main5;
    private JPanel panel_West5;
    private JPanel panel_East5;
    private JPanel panel_North5;
    private JPanel panel_South5;
    private JLabel label_Administrator5;
    private JPanel panel_Center5;
    private JButton button_AddV5;
    private JButton button_AddEmp5;
    private JButton button_DeleteEmp5;
    private JButton button_DeleteV5;
    private JButton button_Logout5;

    public App5()
    {
        button_AddV5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showInputDialog("Add Vehicle:",null);
            }
        });

        button_DeleteV5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showInputDialog("Delete Vehicle:",null);
            }
        });


        button_AddEmp5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showInputDialog("Add Employee:",null);
            }
        });

        button_DeleteEmp5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showInputDialog("Delete Employee:",null);
            }
        });

        button_Logout5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);

                JFrame frame5 = new JFrame("App5");
                frame5.setContentPane(new App5().panel_Main5);
                frame5.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame5.pack();
                frame5.getDefaultCloseOperation();
            }
        });
    }
}
