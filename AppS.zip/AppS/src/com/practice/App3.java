package com.practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App3
{
    public JPanel panel_Main3;
    private JPanel panel_West3;
    private JPanel panel_South3;
    private JPanel panelEast3;
    private JPanel panel_North3;
    private JButton button_Home3;
    private JPanel panel_Center3;
    private JFormattedTextField text_User3;
    private JPasswordField text_Password3;
    private JButton button_LoginS3;
    private JButton button_LoginA3;
    private JButton button_LoginE3;


    public App3()
    {
        button_Home3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);

                JFrame frame3 = new JFrame("App3");
                frame3.setContentPane(new App3().panel_Main3);
                frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame3.pack();
                frame3.getDefaultCloseOperation();
            }
        });
        button_LoginS3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame4 = new JFrame("App4");
                frame4.setContentPane(new App4().panel_Main4);
                frame4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame4.pack();
                frame4.setVisible(true);

                JFrame frame3 = new JFrame("App3");
                frame3.setContentPane(new App3().panel_Main3);
                frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame3.pack();
                frame3.getDefaultCloseOperation();
            }
        });
        button_LoginE3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Welcome to the Employee Account: \n Hourly pay: \n Hours Worked: \n Station Number \n");
            }
        });

        button_LoginA3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame5 = new JFrame("App5");
                frame5.setContentPane(new App5().panel_Main5);
                frame5.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame5.pack();
                frame5.setVisible(true);

                JFrame frame3 = new JFrame("App3");
                frame3.setContentPane(new App3().panel_Main3);
                frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame3.pack();
                frame3.getDefaultCloseOperation();
            }
        });
    }
}
