package com.practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App2
{
    public JPanel panel_Main2;
    private JPanel panel_West2;
    private JPanel panel_East2;
    private JPanel panel_North2;
    private JPanel panel_South2;
    private JPanel panel_Center2;
    private JComboBox comboBox1;
    private JButton button_Request2;
    private JButton button_Home2;


    public App2()
    {

        button_Home2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);

                JFrame frame2 = new JFrame("App2");
                frame2.setContentPane(new App2().panel_Main2);
                frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame2.pack();
                frame2.getDefaultCloseOperation();
                frame2.setVisible(false);
            }
        });
    }

}
