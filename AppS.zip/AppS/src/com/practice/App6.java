package com.practice;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App6 {
    public JPanel panel_Main6;
    private JPanel panel_East6;
    private JPanel panel_South6;
    private JPanel panel_West6;
    private JPanel panel_North6;
    private JPanel panel_Center6;
    private JTextArea text_ContactInfo6;
    private JTextField textF_Complaint6;
    private JLabel label_Complaint6;
    private JButton button_Submit6;
    private JButton button_Home6;

    public App6()
    {
        button_Home6.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);

                JFrame frame6 = new JFrame("App6");
                frame6.setContentPane(new App6().panel_Main6);
                frame6.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame6.pack();
                frame6.getDefaultCloseOperation();
            }
        });
    }
}
