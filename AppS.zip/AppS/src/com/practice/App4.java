package com.practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App4 {
    public JPanel panel_Main4;
    private JPanel panel_West4;
    private JPanel panel_North4;
    private JPanel panel_East4;
    private JPanel panel_South4;
    private JPanel panel_Center4;
    private JButton button_Drivers4;
    private JButton button_Mechanics4;
    private JButton button_Janitors4;
    private JButton button_Cashiers4;
    private JLabel label_StationNo4;
    private JLabel label_StationNa4;
    private JLabel label_NoofEmp4;
    private JButton button_Logout4;


    public App4()
    {
        button_Drivers4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Drivers");
            }
        });

        button_Mechanics4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Mechanics\n1.\n2.\n3.");
            }
        });

        button_Janitors4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Janitors");
            }
        });

        button_Cashiers4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Cashiers");
            }
        });

        button_Logout4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);

                JFrame frame4 = new JFrame("App4");
                frame4.setContentPane(new App4().panel_Main4);
                frame4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame4.pack();
                frame4.getDefaultCloseOperation();
            }
        });
    }
}
