package com.practice;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App
{
    public JPanel panel_Main;
    private JPanel panel_East;
    private JPanel panel_North;
    private JPanel panel_West;
    private JPanel panel_South;
    private JTextPane text_Description;
    private JLabel BB_Main;
    private JButton button_ELogin;
    private JButton button_Routes;
    private JButton button_Requests;
    private JButton button_ContactUs;


    public App()
    {
        // Request Button on Home page
        button_Requests.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame2 = new JFrame("App2");
                frame2.setContentPane(new App2().panel_Main2);
                frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame2.pack();
                frame2.setVisible(true);

                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(false);
            }
        });
        button_ELogin.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame3 = new JFrame("App3");
                frame3.setContentPane(new App3().panel_Main3);
                frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame3.pack();
                frame3.setVisible(true);

                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(false);
            }
        });
        button_Routes.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null,"Routes \n 1. \n 2. \n 3.");
            }
        });
        button_ContactUs.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JFrame frame6 = new JFrame("App6");
                frame6.setContentPane(new App6().panel_Main6);
                frame6.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame6.pack();
                frame6.setVisible(true);

                JFrame frame = new JFrame("App");
                frame.setContentPane(new App().panel_Main);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }

    public static void main(String[] args)
    {
        JFrame frame = new JFrame("App");
        frame.setContentPane(new App().panel_Main);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
